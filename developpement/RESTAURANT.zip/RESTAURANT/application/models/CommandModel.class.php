<?php
class CommandModel {

	public function order() {

		$database = new Database();

		$sql = "SELECT Meal (
			Name,
			Photo,
			Description,
			QuantityInStock,
			SalePrice


		) FROM Meal";

		$values = [$name, $photo, $description, $quantityInStock, $salePrice $_SESSION['user']['Meal']];

		$database->executeSql($sql, $values);

  }

	}






?>
