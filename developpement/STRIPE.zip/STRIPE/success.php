<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div>
		<h2>Merci pour votre achat de : <?= $_GET['product']?></h2>
		<p>numéro de commande <?= $_GET['tid']?></p>
	</div>
</body>
</html>
