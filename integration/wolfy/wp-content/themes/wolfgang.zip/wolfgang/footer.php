<?php wp_nav_menu(array('theme_location'=>'secondary')); ?>
 </nav>
 </header>
<?php wp_footer(); ?>
</body>
</html>
