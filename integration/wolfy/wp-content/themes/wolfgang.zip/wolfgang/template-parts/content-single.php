

<h3 class="products-title"> <?php  the_title(); ?> </h3>
<?php  the_post_thumbnail('full'); ?>
<?php the_content(); ?>
