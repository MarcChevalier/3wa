

<h3 class="products-title"> <?php  the_title(); ?> </h3>
<!-- <?php  the_post_thumbnail('small'); ?> -->
<?php the_excerpt(); ?>
<a href="<?php the_permalink() ?>" class="cta"> En savoir plus </a>
