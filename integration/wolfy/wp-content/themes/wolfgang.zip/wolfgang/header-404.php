<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Mon super site</title>
</head>
<body ?php body_class(); ?>

  <?php get_header(); ?>
    <header>
      <h1>Devenez le Mozart de la moto avec Wolf'<span class="orange">Gang</span> !</h1>





    </header>
